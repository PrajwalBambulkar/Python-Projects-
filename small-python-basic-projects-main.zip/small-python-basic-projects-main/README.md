# small-basic-python-projects
